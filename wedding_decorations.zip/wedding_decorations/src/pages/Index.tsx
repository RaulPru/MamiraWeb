import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Star, Phone, Mail, MapPin, Instagram, Facebook } from "lucide-react";

const Index = () => {
  const services = [
    {
      title: "Decorațiuni pentru Ceremonie",
      description: "Arcuri frumoase, covoare pentru culoar și aranjamente pentru altar pentru a face ceremonia ta de neuitat.",
      image: "/images/ceremony_arches_1.jpeg",
      price: "Începând de la 3.600 lei"
    },
    {
      title: "Centrepieces pentru Recepție",
      description: "Centrepieces elegante pentru mese care creează atmosfera perfectă pentru celebrarea ta.",
      image: "/images/wedding_centerpieces_1.jpeg",
      price: "Începând de la 200 lei/masă"
    },
    {
      title: "Iluminat pentru Locație",
      description: "Soluții de iluminat romantic incluzând ghirlande luminoase, uplighting și aranjamente cu lumânări.",
      image: "/images/venue_lighting_1.jpeg",
      price: "Începând de la 2.700 lei"
    },
    {
      title: "Aranjamente Florale",
      description: "Designuri florale personalizate pentru buchete, cocarde și decorațiuni pentru locație.",
      image: "/images/wedding_centerpieces_2.jpeg",
      price: "Începând de la 900 lei"
    }
  ];

  const portfolio = [
    { image: "/images/wedding_centerpieces_3.jpeg", title: "Nuntă Clasică în Alb" },
    { image: "/images/ceremony_arches_2.jpeg", title: "Ceremonie în Grădină" },
    { image: "/images/reception_tables_1.jpeg", title: "Recepție Aurie" },
    { image: "/images/venue_lighting_2.jpeg", title: "Iluminat Romantic" },
    { image: "/images/wedding_centerpieces_4.jpeg", title: "Centrepieces Elegante" },
    { image: "/images/ceremony_arches_3.jpeg", title: "Arc Exterior" }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Heart className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-display font-bold text-primary">Nunți Elegante</h1>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-foreground hover:text-primary transition-colors">Acasă</a>
            <a href="#services" className="text-foreground hover:text-primary transition-colors">Servicii</a>
            <a href="#portfolio" className="text-foreground hover:text-primary transition-colors">Portofoliu</a>
            <a href="#about" className="text-foreground hover:text-primary transition-colors">Despre Noi</a>
            <a href="#contact" className="text-foreground hover:text-primary transition-colors">Contact</a>
          </nav>
          <Button className="gradient-romantic text-white border-0 shadow-romantic transition-romantic hover:shadow-elegant">
            Cere Ofertă
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 gradient-elegant"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: `url('/images/wedding_centerpieces_1.jpeg')` }}
        ></div>
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-display font-bold text-foreground mb-6">
            Nunta Ta de Vis
            <span className="block text-primary">Frumos Decorată</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Creând momente magice cu decorațiuni elegante care reflectă povestea voastră unică de dragoste
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="gradient-romantic text-white border-0 shadow-romantic transition-romantic hover:shadow-elegant">
              Vezi Lucrările Noastre
            </Button>
            <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white transition-romantic">
              Programează Consultație
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Serviciile Noastre</Badge>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-4">
              Servicii de Decorațiuni pentru Nunți
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              De la ceremonii intime la recepții grandioase, creăm decorațiuni uimitoare pentru fiecare moment
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="group hover:shadow-romantic transition-romantic border-0 shadow-elegant">
                <div className="aspect-square overflow-hidden rounded-t-lg">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-elegant"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-display font-semibold mb-2">{service.title}</h3>
                  <p className="text-muted-foreground mb-4">{service.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-primary font-semibold">{service.price}</span>
                    <Button size="sm" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
                      Aflaă Mai Mult
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Portfolio</Badge>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-4">
              Decorațiuni Recente pentru Nunți
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Aruncă o privire la câteva dintre lucrările noastre recente și inspiră-te pentru ziua ta specială
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {portfolio.map((item, index) => (
              <div key={index} className="group relative overflow-hidden rounded-lg shadow-elegant hover:shadow-romantic transition-romantic">
                <div className="aspect-square">
                  <img 
                    src={item.image} 
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-elegant"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-romantic">
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-white font-display font-semibold text-lg">{item.title}</h3>
                    <div className="flex items-center text-white/80 mt-2">
                      <Star className="h-4 w-4 fill-current mr-1" />
                      <Star className="h-4 w-4 fill-current mr-1" />
                      <Star className="h-4 w-4 fill-current mr-1" />
                      <Star className="h-4 w-4 fill-current mr-1" />
                      <Star className="h-4 w-4 fill-current" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Despre Noi</Badge>
              <h2 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-6">
                Creând Magie din 2015
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                Cu peste 8 ani de experiență în decorațiuni pentru nunți, am avut privilegiul de a face parte din zilele speciale ale mai mult de 500 de cupluri. Pasiunea noastră constă în transformarea locațiilor în spații magice care reflectă povestea unică de dragoste a fiecărui cuplu.
              </p>
              <p className="text-lg text-muted-foreground mb-8">
                De la ceremonii intime în grădină la recepții grandioase în săli de bal, lucrăm îndeaproape cu clienții noștri pentru a le aduce viziunea la viață cu atenție la fiecare detaliu.
              </p>
              <div className="grid grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-3xl font-display font-bold text-primary mb-2">500+</div>
                  <div className="text-sm text-muted-foreground">Nunți Decorate</div>
                </div>
                <div>
                  <div className="text-3xl font-display font-bold text-primary mb-2">8+</div>
                  <div className="text-sm text-muted-foreground">Ani de Experiență</div>
                </div>
                <div>
                  <div className="text-3xl font-display font-bold text-primary mb-2">100%</div>
                  <div className="text-sm text-muted-foreground">Cupluri Fericite</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="/images/wedding_centerpieces_5.jpeg" 
                alt="About Us"
                className="rounded-lg shadow-elegant"
              />
              <div className="absolute -bottom-6 -right-6 w-32 h-32 gradient-romantic rounded-full opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Contact</Badge>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-4">
              Să Planăm Ziua Ta Perfectă
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Gata să începi planificarea? Ia legătura cu noi pentru o consultație gratuită
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-display font-semibold mb-6">Ia Legătura cu Noi</h3>
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 gradient-romantic rounded-full flex items-center justify-center">
                    <Phone className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <div className="font-semibold">Telefon</div>
                    <div className="text-muted-foreground">+40 123 456 789</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 gradient-romantic rounded-full flex items-center justify-center">
                    <Mail className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <div className="font-semibold">Email</div>
                    <div className="text-muted-foreground">salut@nuntieelegante.ro</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 gradient-romantic rounded-full flex items-center justify-center">
                    <MapPin className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <div className="font-semibold">Locație</div>
                    <div className="text-muted-foreground">Str. Florilor 123, București, România</div>
                  </div>
                </div>
              </div>
              
              <div className="mt-8">
                <h4 className="font-semibold mb-4">Urmărește-ne</h4>
                <div className="flex space-x-4">
                  <Button size="icon" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
                    <Instagram className="h-5 w-5" />
                  </Button>
                  <Button size="icon" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
                    <Facebook className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </div>
            
            <Card className="shadow-elegant border-0">
              <CardContent className="p-8">
                <h3 className="text-2xl font-display font-semibold mb-6">Cere o Ofertă</h3>
                <form className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Prenume</label>
                      <input 
                        type="text" 
                        className="w-full px-4 py-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                        placeholder="Ion"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Nume</label>
                      <input 
                        type="text" 
                        className="w-full px-4 py-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                        placeholder="Popescu"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Email</label>
                    <input 
                      type="email" 
                      className="w-full px-4 py-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                      placeholder="ion@exemplu.ro"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Data Nunții</label>
                    <input 
                      type="date" 
                      className="w-full px-4 py-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Mesaj</label>
                    <textarea 
                      rows={4}
                      className="w-full px-4 py-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors resize-none"
                      placeholder="Spune-ne despre nunta ta de vis..."
                    ></textarea>
                  </div>
                  <Button className="w-full gradient-romantic text-white border-0 shadow-romantic transition-romantic hover:shadow-elegant">
                    Trimite Mesajul
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Heart className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-display font-bold">Nunți Elegante</h3>
              </div>
              <p className="text-background/80">
                Creând momente magice de nuntă cu decorațiuni elegante din 2015.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Servicii</h4>
              <ul className="space-y-2 text-background/80">
                <li>Decorațiuni pentru Ceremonie</li>
                <li>Centrepieces pentru Recepție</li>
                <li>Iluminat pentru Locație</li>
                <li>Aranjamente Florale</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Companie</h4>
              <ul className="space-y-2 text-background/80">
                <li>Despre Noi</li>
                <li>Portofoliu</li>
                <li>Mărturii</li>
                <li>Contact</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Informații de Contact</h4>
              <ul className="space-y-2 text-background/80">
                <li>+40 123 456 789</li>
                <li>salut@nuntieelegante.ro</li>
                <li>Str. Florilor 123</li>
                <li>București, România</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-background/20 mt-8 pt-8 text-center text-background/60">
            <p>&copy; 2024 Nunți Elegante. Toate drepturile rezervate.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
